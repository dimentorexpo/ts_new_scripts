let testint;
let operator;
let chatneraspcountleft;
let peoplestatus = document.createElement('div');
peoplestatus.id = 'idforpeopstatus';
peoplestatus.style = 'width: 200px; color: bisque;';

function initializeStartOperStatus() {
    const siderElements = document.getElementsByClassName('ant-layout-sider-children');
    if (siderElements.length > 0) {
        StartOperStatus();
    } else {
        // Если элемент не найден, начинаем наблюдение
        const observer = new MutationObserver((mutations) => {
            const siderElements = document.getElementsByClassName('ant-layout-sider-children');
            if (siderElements.length > 0) {
                StartOperStatus();
                observer.disconnect(); // Прекращаем наблюдение, так как элемент найден
            }
        });

        observer.observe(document.documentElement, {
            childList: true,
            subtree: true
        });
    }
}

function StartOperStatus() {
    if (localStorage.getItem('hidesummaryflag') == null) {
        localStorage.setItem('hidesummaryflag', '1') // 1 список скрыт , 0 список открыт
    }

    document.getElementsByClassName('ant-layout-sider-children')[0].append(peoplestatus)
    chatneraspcountleft = 0;
    testint = setInterval(operstatusleftbar, 6000)
}

async function operstatusleftbar() { // функция замены Script Package вывода списка операторов
    let opstats = []
    let moderresult = '';
    let flagtpkc;
    let operonlinecnt = 0;
    let busycnt = 0;
    let pausecnt = 0;
    let chattpquecountleft = 0;

    flagtpkc = opsection;

    fetchStaticData()
        .then(result => {
            console.log(result);

            // Проверяем, существуют ли и корректны массивы onOperator и unAssigned
            if (!result.onOperator || !Array.isArray(result.onOperator)) {
                throw new Error("'onOperator' отсутствует или не является массивом.");
            }
            if (!result.unAssigned || !Array.isArray(result.unAssigned)) {
                throw new Error("'unAssigned' отсутствует или не является массивом.");
            }

            // Обрабатываем операторов
            for (let i = 0; i < result.onOperator.length; i++) {
                const operstatus = result.onOperator[i].operator.status;
                operator = result.onOperator[i]
                if (operstatus != "Offline") {
                    console.log(operator)
                    processOperatorData(operator, result.unAssigned, true); // Активный оператор
                } else {
                    processOperatorData(operator, result.unAssigned, false); // Неактивный оператор
                }
            }
        })
        .catch(error => {
            console.error("Ошибка при выполнении fetchStaticData:", error);
        });

    // Универсальная функция для обработки операторов
    function processOperatorData(operator, unAssigned, isActive = true) {
        console.log(operator)
        // ТП или ТП ОС
        if ((flagtpkc === 'ТП' || flagtpkc === 'ТП ОС') && operator.operator?.fullName.match(/ТП\D/)) {
            if (isActive) opstats.push(operator);
            updateQueueCount(unAssigned, 'c7bbb211-a217-4ed3-8112-98728dc382d8', value => chattpquecountleft = value);
        }
        // КЦ
        else if (flagtpkc === 'КЦ' && operator.operator?.fullName.match(/КЦ\D/)) {
            if (isActive) opstats.push(operator);
            chatneraspcountleft = unAssigned.reduce((sum, item) => {
                return item.groupId === 'b6f7f34d-2f08-fc19-3661-29ac00842898' ? sum + Number(item.count) : sum;
            }, 0);
        }
        // Prem
        else if (flagtpkc === 'Prem' && operator.groupId === '68932fae-b9f9-6b37-2a52-911b2b6b4f6d' && operator.operator?.fullName.match(/Prem\D/)) {
            if (isActive) opstats.push(operator);
            updateQueueCount(unAssigned, '121527', value => chatneraspcountleft = value, 'kb');
        }
        // Teachers Care
        else if (flagtpkc === 'Teachers Care' && operator.operator?.fullName.match(/Teachers Care\D/)) {
            if (isActive) opstats.push(operator);
            updateQueueCount(unAssigned, null, value => chatneraspcountleft = value, 'kb');
        }
    }

    // Функция для обновления количества нерешённых чатов
    function updateQueueCount(unAssigned, valueToCheck, callback, key = 'groupId') {
        for (let j = 0; j < unAssigned.length; j++) {
            const item = unAssigned[j];
            if ((valueToCheck && item[key] === valueToCheck) || (!valueToCheck && item[key])) {
                callback(item.count);
            }
        }
    }

    peoplestatus.innerHTML = ''

    if (opstats.length != 0) {
        opstats.sort((prev, next) => {
            if (prev.operator.status < next.operator.status) return -1;
            if (prev.operator.status < next.operator.status) return 1;
        });
    }

    let addedFullNames = new Set();
    if (opstats.length) {
        for (let i = 0; i < opstats.length; i++) {
            opstats[i].aCnt = opstats[i].aCnt || 0;

            const operator = opstats[i].operator;
            const divClass = "leftbaropers";
            let divStyle = "";
            let spanBackground = "";
            let spanText = "";

            switch (operator.status) {
                case "Online":
                    operonlinecnt += 1;
                    spanBackground = "green";
                    spanText = "white";
                    break;
                case "Busy":
                    busycnt += 1;
                    divStyle = "opacity:0.8; color:Gold";
                    spanBackground = "gold";
                    spanText = "black";
                    break;
                case "Pause":
                    pausecnt += 1;
                    divStyle = "opacity:0.8; color:Salmon";
                    spanBackground = "FireBrick";
                    spanText = "white";
                    break;
                default:
                    continue;
            }
            if (!addedFullNames.has(operator.fullName)) {
                moderresult += `<div class="${divClass}" style="${divStyle}" name="operrow" value="${operator.id}">` +
                    `<span style="color: ${spanText}; font-size: 13px; background: ${spanBackground}; width: 25px; height: 25px; padding-top:2px; text-align: center; border-radius: 50%; border: 1px solid black;">` +
                    `${opstats[i].aCnt}` +
                    `</span>` +
                    `${operator.fullName}` +
                    '</div>';
                addedFullNames.add(operator.fullName);
            }

        }
    } else {
        moderresult = '';
    }



    if ((flagtpkc == 'ТП' || flagtpkc == 'ТП ОС') && localStorage.getItem('hidesummaryflag') == '1') {

        peoplestatus.innerHTML =
            '<div style="background:#792525; font-weight: 700; text-align: center; letter-spacing: .2rem; text-shadow: 1px 2px 5px rgb(0 0 0 / 55%); border: 1px solid #464343; margin-bottom: 5px;">' + '🚧 Нераспред: ' + chattpquecountleft + '</div>' +
            moderresult + '<br>' +
            '<div id="clicktounhidestatuses" title="По клику откроет общую информацию о том, сколько всего операторов и их количество в разных статусах" style="color:bisque; opacity:0.8; cursor:pointer; text-align:center;">🔽 Открыть</div>' +
            '<div id="opersstats" style="display:none;">' +
            '<div  style="background:#257947; font-weight: 700; text-align: center; border: 1px solid black;">' + '🛠 Онлайн: ' + operonlinecnt + '</div>' +
            '<div style="background: #a3bb1d; color: black; font-weight: 700; text-align: center; border-left: 1px solid black; border-right: 1px solid black; border-bottom: 1px solid black;">' + '⏳ Занят: ' + busycnt + '</div>' +
            '<div style="background:#cf4615; font-weight: 700; text-align: center;border-left: 1px solid black; border-right: 1px solid black; border-bottom: 1px solid black;">' + '🍔 Перерыв: ' + pausecnt + '</div>' +
            '<div  style="background:#492579; font-weight: 700; text-align: center;border-left: 1px solid black; border-right: 1px solid black; border-bottom: 1px solid black;">' + '⚡ Всего: ' + (+pausecnt + busycnt + operonlinecnt) + '</div>' +
            '</div>'

    } else if ((flagtpkc == 'ТП' || flagtpkc == 'ТП ОС') && localStorage.getItem('hidesummaryflag') == '0') {
        peoplestatus.innerHTML =
            '<div style="background:#792525; font-weight: 700; text-align: center; letter-spacing: .2rem; text-shadow: 1px 2px 5px rgb(0 0 0 / 55%); border: 1px solid #464343; margin-bottom: 5px;">' + '🚧 Нераспред: ' + chattpquecountleft + '</div>' +
            moderresult + '<br>' +
            '<div id="clicktounhidestatuses" title="По клику откроет общую информацию о том, сколько всего операторов и их количество в разных статусах"  style="color:bisque; opacity:0.8; cursor:pointer; text-align:center;">🔼 Скрыть</div>' +
            '<div id="opersstats">' +
            '<div style="background:#257947; font-weight: 700; text-align: center; border: 1px solid black;">' + '🛠 Онлайн: ' + operonlinecnt + '</div>' +
            '<div style="background: #a3bb1d; color: black; font-weight: 700; text-align: center; border-left: 1px solid black; border-right: 1px solid black; border-bottom: 1px solid black;">' + '⏳ Занят: ' + busycnt + '</div>' +
            '<div style="background:#cf4615; font-weight: 700; text-align: center;border-left: 1px solid black; border-right: 1px solid black; border-bottom: 1px solid black;">' + '🍔 Перерыв: ' + pausecnt + '</div>' +
            '<div style="background:#492579; font-weight: 700; text-align: center;border-left: 1px solid black; border-right: 1px solid black; border-bottom: 1px solid black;">' + '⚡ Всего: ' + (+pausecnt + busycnt + operonlinecnt) + '</div>' +
            '</div>'
    } else if (flagtpkc != 'ТП' && flagtpkc != 'ТП ОС' && localStorage.getItem('hidesummaryflag') == '1') {
        peoplestatus.innerHTML =
            '<div style="background:#792525; font-weight: 700; text-align: center; letter-spacing: .2rem; text-shadow: 1px 2px 5px rgb(0 0 0 / 55%); border: 1px solid #464343; margin-bottom: 5px;">' + '🚧 Нераспред: ' + chatneraspcountleft + '</div>' +
            moderresult + '<br>' +
            '<div id="clicktounhidestatuses" title="По клику откроет общую информацию о том, сколько всего операторов и их количество в разных статусах"  style="color:bisque; opacity:0.8; cursor:pointer; text-align:center;">🔽 Открыть</div>' +
            '<div id="opersstats" style="display:none">' + '<div  style="background:#257947; font-weight: 700; text-align: center; border: 1px solid black;">' + '🛠 Онлайн: ' + operonlinecnt + '</div>' +
            '<div style="background: #a3bb1d; color: black; font-weight: 700; text-align: center; border-left: 1px solid black; border-right: 1px solid black; border-bottom: 1px solid black;">' + '⏳ Занят: ' + busycnt + '</div>' +
            '<div style="background:#cf4615; font-weight: 700; text-align: center;border-left: 1px solid black; border-right: 1px solid black; border-bottom: 1px solid black;">' + '🍔 Перерыв: ' + pausecnt + '</div>' +
            '<div  style="background:#492579; font-weight: 700; text-align: center;border-left: 1px solid black; border-right: 1px solid black; border-bottom: 1px solid black;">' + '⚡ Всего: ' + (+pausecnt + busycnt + operonlinecnt) + '</div>' +
            '</div>'
    } else if (flagtpkc != 'ТП' && flagtpkc != 'ТП ОС' && localStorage.getItem('hidesummaryflag') == '0') {
        peoplestatus.innerHTML =
            '<div style="background:#792525; font-weight: 700; text-align: center; letter-spacing: .2rem; text-shadow: 1px 2px 5px rgb(0 0 0 / 55%); border: 1px solid #464343; margin-bottom: 5px;">' + '🚧 Нераспред: ' + chatneraspcountleft + '</div>' +
            moderresult + '<br>' +
            '<div id="clicktounhidestatuses" title="По клику откроет общую информацию о том, сколько всего операторов и их количество в разных статусах"  style="color:bisque; opacity:0.8; cursor:pointer; text-align:center;">🔼 Скрыть</div>' +
            '<div id="opersstats">' + '<div  style="background:#257947; font-weight: 700; text-align: center; border: 1px solid black;">' + '🛠 Онлайн: ' + operonlinecnt + '</div>' +
            '<div style="background: #a3bb1d; color: black; font-weight: 700; text-align: center; border-left: 1px solid black; border-right: 1px solid black; border-bottom: 1px solid black;">' + '⏳ Занят: ' + busycnt + '</div>' +
            '<div style="background:#cf4615; font-weight: 700; text-align: center;border-left: 1px solid black; border-right: 1px solid black; border-bottom: 1px solid black;">' + '🍔 Перерыв: ' + pausecnt + '</div>' +
            '<div  style="background:#492579; font-weight: 700; text-align: center;border-left: 1px solid black; border-right: 1px solid black; border-bottom: 1px solid black;">' + '⚡ Всего: ' + (+pausecnt + busycnt + operonlinecnt) + '</div>' +
            '</div>'
    }

    document.getElementById('clicktounhidestatuses').onclick = function () {
        if (document.getElementById('clicktounhidestatuses').textContent == '🔽 Открыть') {
            document.getElementById('opersstats').style.display = '';
            document.getElementById('clicktounhidestatuses').textContent = '🔼 Скрыть'
            localStorage.setItem('hidesummaryflag', '0')
        } else if (document.getElementById('clicktounhidestatuses').textContent == '🔼 Скрыть') {
            document.getElementById('opersstats').style.display = 'none';
            document.getElementById('clicktounhidestatuses').textContent = '🔽 Открыть'
            localStorage.setItem('hidesummaryflag', '1')
        }
    }


    let arofpers = document.getElementsByName('operrow')
    for (let i = 0; i < arofpers.length; i++) {
        arofpers[i].onclick = function () {
            if (document.getElementById('AF_ChatHis').style.display == 'none')
                document.getElementById('opennewcat').click()

            setTimeout(function () {
                let massivvidapspiskaoperatorov = document.getElementById('operatorstp')
                for (let k = 1; k < massivvidapspiskaoperatorov.length; k++) {
                    if (arofpers[i].getAttribute('value') == massivvidapspiskaoperatorov.children[k].value) {
                        massivvidapspiskaoperatorov.children[k].selected = true
                        findchatsoper()
                    }
                }
            }, 1000)
        }
    }

    for (let i = 0; document.getElementsByClassName('app-content')[1].children[i] != undefined; i++) {
        if (document.getElementsByClassName('app-content')[1].children[i].id == 'people_head')
            document.getElementsByClassName('app-content')[1].children[i].remove()
    }

}

initializeStartOperStatus();